﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITY
{
    [Table("TAREAS")]
    public class Tarea
    {
        [Key]
        [Column("IDTAREA")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdTarea { get; set; }

        [Required]
        [Column("IDSIEMBRA")]
        public int IdSiembra { get; set; }

        [ForeignKey("IdSiembra")]
        public virtual Siembra Siembra { get; set; }

        [Column("TIPO")]
        [StringLength(20)]
        public string Tipo { get; set; }

        [Required]
        [Column("FECHATAREAPROGRAMADA")]
        public DateTime FechaTareaProgramada { get; set; }

        [Column("FECHATAREATERMINADA")]
        public DateTime? FechaTareaTerminada { get; set; }

        [Column("URGENCIA")]
        public int? Urgencia { get; set; }

        [Column("DESCRIPCIÓN")]
        public string Descripcion { get; set; }

        [Required]
        [Column("ESTADO")]
        [StringLength(1)]
        public string Estado { get; set; } = "1";
    }
}

